import test from "node:test";
import assert from "node:assert/strict";
import {
  MAX_SPEECH_RETRIES,
  SPEECH_BACKOFF_DELAYS,
  appendTranscript,
  isRecoverableSpeechError,
  recognitionErrorText,
} from "./voice.ts";

/**
 * Test harness simulating the Web Speech Recognition recovery lifecycle.
 * Emulates the exact state machine and concurrency controls implemented in useVoice.ts.
 */
type MockRecognitionEvent = {
  resultIndex: number;
  results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }>;
};

type ScheduledTimer = {
  id: number;
  delay: number;
  cb: () => void;
};

class MockSpeechRecognition {
  lang = "en-IN";
  continuous = true;
  interimResults = true;
  onstart: (() => void) | null = null;
  onresult: ((e: MockRecognitionEvent) => void) | null = null;
  onerror: ((e: { error: string }) => void) | null = null;
  onend: (() => void) | null = null;

  started = false;
  aborted = false;
  stopped = false;

  start() {
    this.started = true;
  }
  stop() {
    this.stopped = true;
    if (this.onend) this.onend();
  }
  abort() {
    this.aborted = true;
    if (this.onend) this.onend();
  }
}

class SimulatedVoiceEngine {
  rec: MockSpeechRecognition | null = null;
  instanceId = 0;
  activeInstances: MockSpeechRecognition[] = [];
  want = false;
  retryCount = 0;
  needsRetry = false;
  listening = false;
  reconnecting = false;
  reconnected = false;
  error: string | null = null;
  draft = "";
  interim = "";
  listenedMs = 0;
  startedAt = 0;
  scheduledTimer: ScheduledTimer | null = null;
  nextTimerId = 1;
  submitted = false;

  startListening(initialDraft = "") {
    this.clearTimers();
    this.draft = initialDraft;
    this.want = true;
    this.retryCount = 0;
    this.needsRetry = false;
    this.error = null;
    this.reconnecting = false;
    this.reconnected = false;
    this.startNow();
  }

  stopListening() {
    this.want = false;
    this.needsRetry = false;
    this.retryCount = 0;
    this.clearTimers();
    this.reconnecting = false;
    if (this.rec) {
      this.rec.stop();
      this.rec = null;
    }
    this.listening = false;
  }

  silence() {
    this.want = false;
    this.needsRetry = false;
    this.retryCount = 0;
    this.clearTimers();
    this.reconnecting = false;
    this.reconnected = false;
    if (this.rec) {
      this.rec.abort();
      this.rec = null;
    }
    this.finishListening();
    this.interim = "";
    this.listening = false;
  }

  clearTimers() {
    this.scheduledTimer = null;
  }

  finishListening(now = 1000) {
    if (this.startedAt > 0) {
      this.listenedMs += Math.round(now - this.startedAt);
      this.startedAt = 0;
    }
  }

  startNow(now = 0) {
    if (!this.want) return;

    if (this.rec) {
      this.rec.abort();
      this.rec = null;
    }

    const currentId = ++this.instanceId;
    let ended = false;
    const r = new MockSpeechRecognition();
    this.activeInstances.push(r);
    this.rec = r;

    r.onstart = () => {
      if (this.instanceId !== currentId) return;
      this.startedAt = now;
      this.listening = true;
      if (this.retryCount > 0) {
        this.needsRetry = false;
        this.reconnecting = false;
        this.reconnected = true;
        this.error = null;
      } else {
        this.reconnecting = false;
        this.error = null;
      }
    };

    r.onresult = (e: MockRecognitionEvent) => {
      if (this.instanceId !== currentId) return;
      this.retryCount = 0;
      this.needsRetry = false;
      this.reconnecting = false;
      this.error = null;

      let pending = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const res = e.results[i];
        if (res.isFinal) {
          this.draft = appendTranscript(this.draft, res[0].transcript);
        } else {
          pending += res[0].transcript;
        }
      }
      this.interim = pending;
    };

    r.onerror = (e: { error: string }) => {
      if (this.instanceId !== currentId) return;
      if (e.error === "aborted") return;

      if (isRecoverableSpeechError(e.error) && this.want) {
        if (this.retryCount < MAX_SPEECH_RETRIES) {
          this.needsRetry = true;
          this.reconnecting = true;
          return;
        }
        this.want = false;
        this.needsRetry = false;
        this.reconnecting = false;
        this.error = recognitionErrorText("network", true).text;
        return;
      }

      const { text, fatal } = recognitionErrorText(e.error);
      if (fatal) {
        this.want = false;
        this.needsRetry = false;
        this.retryCount = 0;
        this.reconnecting = false;
      }
      this.error = text;
    };

    r.onend = () => {
      if (ended || this.instanceId !== currentId) return;
      ended = true;

      this.interim = "";
      this.finishListening(now + 100);
      if (this.rec === r) this.rec = null;

      if (this.want) {
        if (this.needsRetry) {
          this.needsRetry = false;
          const delay = SPEECH_BACKOFF_DELAYS[this.retryCount] ?? 1500;
          this.retryCount += 1;
          this.reconnecting = true;
          this.scheduledTimer = {
            id: this.nextTimerId++,
            delay,
            cb: () => {
              if (this.want && !this.rec) {
                this.startNow(now + delay);
              }
            },
          };
        } else {
          this.scheduledTimer = {
            id: this.nextTimerId++,
            delay: 200,
            cb: () => {
              if (this.want && !this.rec) {
                this.startNow(now + 200);
              }
            },
          };
        }
      } else {
        this.listening = false;
        this.reconnecting = false;
      }
    };

    r.start();
    if (r.onstart) r.onstart();
  }

  runTimer() {
    if (this.scheduledTimer) {
      const t = this.scheduledTimer;
      this.scheduledTimer = null;
      t.cb();
    }
  }
}

// ================= TEST SUITE =================

test("1. Transient network error followed by successful recovery", () => {
  const engine = new SimulatedVoiceEngine();
  engine.startListening("Initial draft");

  assert.equal(engine.listening, true);
  assert.equal(engine.reconnecting, false);

  // Deliver partial speech on first instance
  engine.rec?.onresult?.({
    resultIndex: 0,
    results: [{ isFinal: true, 0: { transcript: "I developed a service" } }],
  });
  assert.equal(engine.draft, "Initial draft I developed a service");

  // Simulate network interruption
  const inst1 = engine.rec!;
  inst1.onerror?.({ error: "network" });
  assert.equal(engine.needsRetry, true);
  assert.equal(engine.reconnecting, true);
  assert.equal(engine.want, true); // User intent preserved!

  // Browser fires onend after onerror
  inst1.onend?.();
  assert.ok(engine.scheduledTimer !== null);
  assert.equal(engine.scheduledTimer.delay, 400); // First backoff attempt: 400ms

  // Advance timer (reconnect)
  engine.runTimer();
  assert.equal(engine.reconnecting, false);
  assert.equal(engine.reconnected, true);
  assert.equal(engine.error, null);

  // Deliver speech on recovered instance (successful recognition activity)
  engine.rec?.onresult?.({
    resultIndex: 0,
    results: [{ isFinal: true, 0: { transcript: "using React and FastAPI." } }],
  });
  assert.equal(engine.retryCount, 0); // Reset after successful recognition activity
  assert.equal(engine.draft, "Initial draft I developed a service using React and FastAPI.");
});

test("2. Repeated network errors and retry exhaustion", () => {
  const engine = new SimulatedVoiceEngine();
  engine.startListening();

  // Retry 1 (400ms)
  engine.rec?.onerror?.({ error: "network" });
  engine.rec?.onend?.();
  assert.equal(engine.reconnecting, true);
  assert.equal(engine.scheduledTimer?.delay, 400);
  engine.runTimer();

  // Retry 2 (800ms)
  engine.rec?.onerror?.({ error: "network" });
  engine.rec?.onend?.();
  assert.equal(engine.reconnecting, true);
  assert.equal(engine.scheduledTimer?.delay, 800);
  engine.runTimer();

  // Retry 3 (1500ms)
  engine.rec?.onerror?.({ error: "network" });
  engine.rec?.onend?.();
  assert.equal(engine.reconnecting, true);
  assert.equal(engine.scheduledTimer?.delay, 1500);
  engine.runTimer();

  // 4th consecutive failure: retries exhausted!
  engine.rec?.onerror?.({ error: "network" });
  assert.equal(engine.want, false);
  assert.equal(engine.reconnecting, false);
  assert.match(engine.error ?? "", /multiple attempts/);

  // Verify onend does not schedule another timer
  engine.rec?.onend?.();
  assert.equal(engine.scheduledTimer, null);
  assert.equal(engine.listening, false);
});

test("3. User cancellation during recovery cancels pending retry", () => {
  const engine = new SimulatedVoiceEngine();
  engine.startListening("Some transcript");

  engine.rec?.onerror?.({ error: "network" });
  engine.rec?.onend?.();
  assert.ok(engine.scheduledTimer !== null);

  // User clicks "Stop & Review" while reconnect timer is pending
  engine.stopListening();
  assert.equal(engine.want, false);
  assert.equal(engine.reconnecting, false);
  assert.equal(engine.scheduledTimer, null);

  // Verify transcript is retained
  assert.equal(engine.draft, "Some transcript");
});

test("4. Component unmount / silence cleans up all timers and aborts", () => {
  const engine = new SimulatedVoiceEngine();
  engine.startListening();

  engine.rec?.onerror?.({ error: "network" });
  engine.rec?.onend?.();
  assert.ok(engine.scheduledTimer !== null);

  // Unmount invokes silence()
  engine.silence();
  assert.equal(engine.want, false);
  assert.equal(engine.scheduledTimer, null);
  assert.equal(engine.rec, null);
  assert.equal(engine.listening, false);
});

test("5. Permission-denied errors are immediately fatal with zero retries", () => {
  const engine = new SimulatedVoiceEngine();
  engine.startListening();

  engine.rec?.onerror?.({ error: "not-allowed" });
  assert.equal(engine.want, false);
  assert.equal(engine.needsRetry, false);
  assert.equal(engine.reconnecting, false);
  assert.match(engine.error ?? "", /Microphone permission was denied/);

  engine.rec?.onend?.();
  assert.equal(engine.scheduledTimer, null);
});

test("6. Unsupported recognition constructor handled safely", () => {
  const isRecoverable = isRecoverableSpeechError("audio-capture");
  assert.equal(isRecoverable, false);
  const err = recognitionErrorText("audio-capture");
  assert.equal(err.fatal, true);
  assert.match(err.text, /No microphone was found/);
});

test("7. onerror followed by onend schedules exactly one backoff restart", () => {
  const engine = new SimulatedVoiceEngine();
  engine.startListening();

  const inst = engine.rec!;
  inst.onerror?.({ error: "network" });
  assert.equal(engine.scheduledTimer, null); // Scheduled in onend, not onerror

  inst.onend?.();
  const timer = engine.scheduledTimer as ScheduledTimer | null;
  assert.ok(timer !== null);
  const timerId = timer.id;

  // Verify only one timer was registered
  assert.equal(engine.retryCount, 1);
  assert.equal(timer.id, timerId);
});

test("8. Duplicate onend events do not trigger duplicate restarts", () => {
  const engine = new SimulatedVoiceEngine();
  engine.startListening();

  const inst = engine.rec!;
  inst.onerror?.({ error: "network" });
  inst.onend?.();

  const firstTimerId = engine.scheduledTimer?.id;
  assert.ok(firstTimerId !== undefined);

  // Duplicate onend event from buggy browser engine
  inst.onend?.();
  assert.equal(engine.scheduledTimer?.id, firstTimerId); // Unchanged
  assert.equal(engine.retryCount, 1); // Not double-incremented
});

test("9. Transcript preservation across reconnects and manual typing", () => {
  const engine = new SimulatedVoiceEngine();
  engine.startListening("Initial typing.");

  // Speech 1
  engine.rec?.onresult?.({
    resultIndex: 0,
    results: [{ isFinal: true, 0: { transcript: "Spoken part 1." } }],
  });
  assert.equal(engine.draft, "Initial typing. Spoken part 1.");

  // Network disconnect & recovery
  engine.rec?.onerror?.({ error: "network" });
  engine.rec?.onend?.();
  engine.runTimer();

  // Speech 2
  engine.rec?.onresult?.({
    resultIndex: 0,
    results: [{ isFinal: true, 0: { transcript: "Spoken part 2." } }],
  });
  assert.equal(engine.draft, "Initial typing. Spoken part 1. Spoken part 2.");
});

test("10. No concurrent recognition instances during recovery", () => {
  const engine = new SimulatedVoiceEngine();
  engine.startListening();
  const inst1 = engine.rec!;

  // Trigger retry
  inst1.onerror?.({ error: "network" });
  inst1.onend?.();

  // Before timer runs, rec is null (not running concurrently)
  assert.equal(engine.rec, null);

  // After timer runs, exactly one instance is active
  engine.runTimer();
  assert.ok(engine.rec !== null);
  assert.notEqual(engine.rec, inst1);
});

test("11. No accidental answer submission occurs during recovery", () => {
  const engine = new SimulatedVoiceEngine();
  engine.startListening();

  engine.rec?.onerror?.({ error: "network" });
  engine.rec?.onend?.();
  engine.runTimer();

  assert.equal(engine.submitted, false);
});
